package com.mt.cardletter.fragment.seckill;

import com.mt.cardletter.R;
import com.mt.cardletter.fragment.BaseFragment;

/**
 * jk 超值购
 */
public class OverflowFragment extends BaseFragment {

    @Override
    protected int setLayoutResouceId() {
        return R.layout.fragment_overflow;
    }

    @Override
    public void initData() {

    }
}
