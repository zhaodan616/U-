package com.mt.cardletter.activity;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Message;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.model.LatLng;
import com.mt.cardletter.R;
import com.mt.cardletter.activity.base.BaseActivity;
import com.mt.cardletter.app.AppContext;
import com.mt.cardletter.entity.merchant.Bank;
import com.mt.cardletter.entity.merchant.Goods;
import com.mt.cardletter.https.HttpSubscriber;
import com.mt.cardletter.https.SubscriberOnListener;
import com.mt.cardletter.https.base_net.CardLetterRequestApi;
import com.mt.cardletter.utils.Constant;
import com.mt.cardletter.utils.ToastUtils;
import com.mt.cardletter.utils.UIHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Date:2018/1/3
 * Time:16:24
 * author:demons
 */

public class LoactionActivity extends BaseActivity implements SensorEventListener {
    private double lat;
    private double lon;
    private TextView name;
    private FrameLayout back;

    private View view;
    private TextView map_tv;
    private ImageView map_img;
    private List<Marker> markers;
    private List<Bank.DataBean> banks;
    // 定位相关
    LocationClient mLocClient;
    public MyLocationListenner myListener = new MyLocationListenner();
    boolean isFirstLoc = true; // 是否首次定位
    private MyLocationData locData;
    private MyLocationConfiguration.LocationMode mCurrentMode;
    private Double lastX = 0.0;
    private float mCurrentDirection = 0;
    private double mCurrentLat = 0.0;
    private double mCurrentLon = 0.0;
    private float mCurrentAccracy;
    private SensorManager mSensorManager;
    /**
     * MapView 是地图主控件
     */
    private MapView mMapView;
    private BaiduMap mBaiduMap;
    private Marker mMarkerA;
    private Marker mMarkerB;
    private Marker mMarkerC;
    private Marker mMarkerD;
    private InfoWindow mInfoWindow;
//    初始化全局 bitmap 信息，不用时及时 recycle
//    BitmapDescriptor bdA = BitmapDescriptorFactory
//            .fromResource(R.drawable.icon_marka);
//    BitmapDescriptor bdB = BitmapDescriptorFactory
//            .fromResource(R.drawable.icon_markb);
//    BitmapDescriptor bdC = BitmapDescriptorFactory
//            .fromResource(R.drawable.icon_markc);
//    BitmapDescriptor bdD = BitmapDescriptorFactory
//            .fromResource(R.drawable.icon_markd);
//    BitmapDescriptor bd = BitmapDescriptorFactory
//            .fromResource(R.drawable.icon_gcoding);
    BitmapDescriptor bdGround = BitmapDescriptorFactory
            .fromResource(R.drawable.ground_overlay);
    /**
     * 附近商家集合
     */
    private List<Goods.DataBeanX.CardfindListBean.DataBean> merchantList;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_location;
    }

    @Override
    public void initView() {
        setSwipeBackEnable(false);//禁止侧滑退出
        lon = AppContext.getInstance().getLon();
        lat = AppContext.getInstance().getLat();
        view = View.inflate(this, R.layout.icon_map_marker, null);
        map_tv = (TextView) view.findViewById(R.id.map_icon_tv);
        map_img = (ImageView) view.findViewById(R.id.map_icon_img);
        merchantList = new ArrayList<>();
        markers = new ArrayList<>();
        banks = new ArrayList<>();
        name = (TextView) findViewById(R.id.title_name);
        name.setText("附近商家");

        back = (FrameLayout) findViewById(R.id.com_back_click);
        back.setVisibility(View.VISIBLE);

        mMapView = (MapView) findViewById(R.id.bmapView);
        mBaiduMap = mMapView.getMap();

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);//获取传感器管理服务
        mCurrentMode = MyLocationConfiguration.LocationMode.NORMAL;
        // 开启定位图层
        mBaiduMap.setMyLocationEnabled(true);
        // 定位初始化
        mLocClient = new LocationClient(this);
        mLocClient.registerLocationListener(myListener);
        LocationClientOption option = new LocationClientOption();
        option.setOpenGps(true);      // 打开gps
        option.setCoorType("bd09ll"); // 设置坐标类型
        option.setScanSpan(1000);     //间隔定位的时间
        //option.setNeedDeviceDirect(true); //返回的定位结果包含手机机头方向
        mLocClient.setLocOption(option);
        mLocClient.start();

//        MapStatusUpdate msu = MapStatusUpdateFactory.zoomTo(14.0f);
//        mBaiduMap.setMapStatus(msu);
//        initOverlay();

    }

    private void initMerchantLatLng() {
        // TODO 使用商家经纬度
        for (Goods.DataBeanX.CardfindListBean.DataBean data : merchantList) {
            if (merchantList.size() > 0) {
                isOpen = false;
            }
            map_tv.setText(data.getName());
            //map_img.setImageResource(R.);
            double lat = data.getLat();
            double lng = data.getLng();
            LatLng latLng = new LatLng(lng, lat);
            //marker.setIcon(BitmapDescriptorFactory.fromView(view));
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLng);
            markerOptions.icon(BitmapDescriptorFactory.fromView(view));
            markerOptions.zIndex(9);
            markerOptions.draggable(false);
            Marker mMarker = (Marker) (mBaiduMap.addOverlay(markerOptions));
            markers.add(mMarker);
        }
    }

    /**
     * 实时监听
     *
     * @param locData
     */
    private boolean isOpen = true;

    private void initOverlay(MyLocationData locData) {
        /**
         * 根据商家显示   locData
         */
        if (isOpen) {
            initMerchantLatLng();
        }
        /**
         * 静态地标
         */
//        LatLng llA = new LatLng(32.02004, 118.763108);
//        LatLng llB = new LatLng(32.02104, 118.763008);
//        LatLng llC = new LatLng(32.01004, 118.763108);
//        LatLng llD = new LatLng(32.02004, 118.763208);
//        MarkerOptions ooA = new MarkerOptions().position(llA).icon(bdA)
//                .zIndex(9).draggable(true);
//        mMarkerA = (Marker) (mBaiduMap.addOverlay(ooA));
//        MarkerOptions ooB = new MarkerOptions().position(llB).icon(bdB)
//                .zIndex(5);
//        mMarkerB = (Marker) (mBaiduMap.addOverlay(ooB));

//        MarkerOptions ooC = new MarkerOptions().position(llC).icon(bdC)
//                .perspective(false).anchor(0.5f, 0.5f).rotate(30).zIndex(7);
//
//        mMarkerC = (Marker) (mBaiduMap.addOverlay(ooC));
        /**
         * 变化地标
         */
//        ArrayList<BitmapDescriptor> giflist = new ArrayList<BitmapDescriptor>();
//        giflist.add(bdA);
//        giflist.add(bdB);
//        giflist.add(bdC);
//        MarkerOptions ooD = new MarkerOptions().position(llD).icons(giflist)
//                .zIndex(0).period(10);
//        mMarkerD = (Marker) (mBaiduMap.addOverlay(ooD));
        /**
         * 添加底层叠加层
         */
//        LatLng southwest = new LatLng(39.92235, 116.380338);
//        LatLng northeast = new LatLng(39.947246, 116.414977);
//        LatLngBounds bounds = new LatLngBounds.Builder().include(northeast)
//                .include(southwest).build();
//
//        OverlayOptions ooGround = new GroundOverlayOptions()
//                .positionFromBounds(bounds).image(bdGround).transparency(0.8f);
//        mBaiduMap.addOverlay(ooGround);
//
//        MapStatusUpdate u = MapStatusUpdateFactory
//                .newLatLng(bounds.getCenter());
//        mBaiduMap.setMapStatus(u);
//        mBaiduMap.setOnMarkerDragListener(new BaiduMap.OnMarkerDragListener() {
//            public void onMarkerDrag(Marker marker) {
//            }
//
//            public void onMarkerDragEnd(Marker marker) {
////                Toast.makeText(
////                        LoactionActivity.this,
////                        "拖拽结束，新位置：" + marker.getPosition().latitude + ", "
////                                + marker.getPosition().longitude,
////                        Toast.LENGTH_LONG).show();
//            }
//
//            public void onMarkerDragStart(Marker marker) {
//            }
//        });
    }

    @Override
    public void initListener() {
        mBaiduMap.setOnMarkerClickListener(new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(final Marker marker) {
//                Button button = new Button(getApplicationContext());
//                button.setBackgroundResource(R.drawable.popup);
//                InfoWindow.OnInfoWindowClickListener listener = null;
//                if (marker == mMarkerA || marker == mMarkerD) {
//                    button.setText("更改位置");
//                    button.setTextColor(Color.BLACK);
//                    button.setWidth(300);
//
//                    listener = new InfoWindow.OnInfoWindowClickListener() {
//                        public void onInfoWindowClick() {
//                            LatLng ll = marker.getPosition();
//                            LatLng llNew = new LatLng(ll.latitude + 0.005,
//                                    ll.longitude + 0.005);
//                            marker.setPosition(llNew);
//                            mBaiduMap.hideInfoWindow();
//                        }
//                    };
//                    LatLng ll = marker.getPosition();
//                    mInfoWindow = new InfoWindow(BitmapDescriptorFactory.fromView(button), ll, -47, listener);
//                    mBaiduMap.showInfoWindow(mInfoWindow);
//                } else if (marker == mMarkerB) {
//                    button.setText("更改图标");
//                    button.setTextColor(Color.BLACK);
//                    button.setOnClickListener(new View.OnClickListener() {
//                        public void onClick(View v) {
//                            marker.setIcon(bd);
//                            mBaiduMap.hideInfoWindow();
//                        }
//                    });
//                    LatLng ll = marker.getPosition();
//                    mInfoWindow = new InfoWindow(button, ll, -47);
//                    mBaiduMap.showInfoWindow(mInfoWindow);
//                } else if (marker == mMarkerC) {
//                    button.setText("删除");
//                    button.setTextColor(Color.BLACK);
//                    button.setOnClickListener(new View.OnClickListener() {
//                        public void onClick(View v) {
//                            marker.remove();
//                            mBaiduMap.hideInfoWindow();
//                        }
//                    });
//                    LatLng ll = marker.getPosition();
//                    mInfoWindow = new InfoWindow(button, ll, -47);
//                    mBaiduMap.showInfoWindow(mInfoWindow);
//                }
                for (int i = 0; i < markers.size(); i++) {
                    if (marker == markers.get(i)) {
                        Intent intent = LoactionActivity.this.getIntent();
                        intent.setClass(LoactionActivity.this, SetailsActivity.class);
                        if (merchantList.get(i) != null) {
                            intent.putExtra("cardfind_id", merchantList.get(i).getId() + "");
                            intent.putExtra("bank", banks.get(Integer.parseInt(merchantList.get(i).getBankcard()) - 1).getName());
                            intent.putExtra("bank_url", banks.get(Integer.parseInt(merchantList.get(i).getBankcard()) - 1).getCardThumb());
                        }
                        UIHelper.showDetails(LoactionActivity.this, intent);
                    }
                }
                return true;
            }
        });
    }


    /**
     * 定位SDK监听函数
     */
    public class MyLocationListenner implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {
            // map view 销毁后不在处理新接收的位置
            if (location == null || mMapView == null) {
                return;
            }
            location.getCity();
            mCurrentLat = location.getLatitude();
            mCurrentLon = location.getLongitude();
            mCurrentAccracy = location.getRadius();
//            mCurrentDirection = location.getDirection();
//            System.out.println("mCurrentDirection:"+mCurrentDirection);
            locData = new MyLocationData.Builder()
                    .accuracy(location.getRadius())
                    // 此处设置开发者获取到的方向信息，顺时针0-360
                    .direction(mCurrentDirection)
                    .latitude(location.getLatitude())
                    .longitude(location.getLongitude())
                    .build();
            mBaiduMap.setMyLocationData(locData);
            if (isFirstLoc) {
                isFirstLoc = false;
                LatLng ll = new LatLng(location.getLatitude(),
                        location.getLongitude());
                MapStatus.Builder builder = new MapStatus.Builder();
                builder.target(ll).zoom(15.0f);
                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(builder.build()));
                //  }


            }
            System.out.println("jk-------------" + "地图回调");

            initOverlay(locData);
        }

        public void onReceivePoi(BDLocation poiLocation) {
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        double x = sensorEvent.values[SensorManager.DATA_X];
        if (Math.abs(x - lastX) > 1.0) {
            mCurrentDirection = (int) x;
            locData = new MyLocationData.Builder()
                    .accuracy(mCurrentAccracy)
                    // 此处设置开发者获取到的方向信息，顺时针0-360
                    .direction(mCurrentDirection).latitude(mCurrentLat)
                    .longitude(mCurrentLon).build();
            mBaiduMap.setMyLocationData(locData);
        }
        lastX = x;

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void initData() {
        //TODO 经纬度  地区
        loadData(1, 100 + "", "" + 1, "", Constant.CITY_ID,Constant.MY_BANK, lat + "", lon + "");
        toLogin(Constant.Access_Token);
    }

    @Override
    protected void handler(Message msg) {

    }


    @Override
    protected void onPause() {
        // MapView的生命周期与Activity同步，当activity挂起时需调用MapView.onPause()
        mMapView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        // MapView的生命周期与Activity同步，当activity恢复时需调用MapView.onResume()
        mMapView.onResume();
        super.onResume();
        //为系统的方向传感器注册监听器
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
                SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onStop() {
        //取消注册传感器监听
        mSensorManager.unregisterListener(this);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        // MapView的生命周期与Activity同步，当activity销毁时需调用MapView.destroy()
        // 退出时销毁定位
        if (mLocClient!=null){
            mLocClient.stop();
        }
        // 关闭定位图层
        if (mBaiduMap != null){
            mBaiduMap.setMyLocationEnabled(false);
        }
        if (mMapView != null){
            mMapView.onDestroy();
            mMapView = null;
        }
        super.onDestroy();
        // 回收 bitmap 资源
//        bdA.recycle();
//        bdB.recycle();
//        bdC.recycle();
//        bdD.recycle();
        //bd.recycle();
        if (bdGround != null){
            bdGround.recycle();
        }

    }

    private void loadData(final int upDataFlag, String list_rows, String page, String category_id, String city, String bankcard, String lng, String lat) {
        lng = AppContext.getInstance().getLat() + "";
        lat = AppContext.getInstance().getLon() + "";
        CardLetterRequestApi.getInstance().getFindMerchant(
                Constant.Access_Token, list_rows, page, category_id, city, bankcard, lng, lat, "", new HttpSubscriber<Goods>(new SubscriberOnListener<Goods>() {
                    @Override
                    public void onSucceed(Goods data) {
                        if (data.getCode() == 0) {
                            List<Goods.DataBeanX.CardfindListBean.DataBean> data1 = data.getData().getCardfindList().getData();
                            merchantList = data1;
                        }
                    }

                    @Override
                    public void onError(int code, String msg) {
                        ToastUtils.showShort(LoactionActivity.this, "网络异常");
                    }
                }, LoactionActivity.this));
    }

    private void toLogin(String ak) {
        CardLetterRequestApi.getInstance().getBank(ak, new HttpSubscriber<Bank>(new SubscriberOnListener<Bank>() {
            @Override
            public void onSucceed(Bank data) {
                if (data.getCode() == 0) {
                    banks = data.getData();

                }
            }

            @Override
            public void onError(int code, String msg) {
            }
        }, LoactionActivity.this));
    }
}
