package com.mt.cardletter.view.citydialog;

public interface ProvinceCallBack {
	
	public void onWhellFinish(String province, String city,String code,String abbr);

}
