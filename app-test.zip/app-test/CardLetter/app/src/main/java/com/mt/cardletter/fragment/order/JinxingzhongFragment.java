package com.mt.cardletter.fragment.order;


import com.mt.cardletter.R;
import com.mt.cardletter.fragment.BaseFragment;



/**
 * 正在进行
 */
public class JinxingzhongFragment extends BaseFragment {


    public JinxingzhongFragment() {

    }


    @Override
    protected int setLayoutResouceId() {
        return R.layout.fragment_apmprepare;
    }

    @Override
    public void initData() {

    }
}
