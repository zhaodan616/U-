package com.mt.cardletter.activity;

import android.os.Message;
import com.mt.cardletter.R;
import com.mt.cardletter.activity.base.BaseActivity;

public class NewsListActivity extends BaseActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_news_list;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initListener() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void handler(Message msg) {

    }
}
