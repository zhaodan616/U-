package com.mt.cardletter.fragment.order;



import com.mt.cardletter.fragment.BaseFragment;


/**
 * 全部
 */
public class WholeFragment extends BaseFragment {

    public WholeFragment() {
    }
    @Override
    protected int setLayoutResouceId() {
        return com.mt.cardletter.R.layout.fragment_apmprepare;
    }

    @Override
    public void initData() {

    }
}
