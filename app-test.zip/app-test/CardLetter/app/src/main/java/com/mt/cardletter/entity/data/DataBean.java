package com.mt.cardletter.entity.data;

import java.io.Serializable;

/**
 * Created by MQ on 2016/11/11.
 */

public class DataBean implements Serializable {
    public String name;
}
