package com.mt.cardletter.fragment.order;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mt.cardletter.R;
import com.mt.cardletter.fragment.BaseFragment;


/**
 * 待付款
 */
public class NoPaymentFragment extends BaseFragment {


    public NoPaymentFragment() {
    }

    @Override
    protected int setLayoutResouceId() {
        return R.layout.fragment_apmprepare;
    }

    @Override
    public void initData() {

    }

}
