package com.mt.cardletter.view.rollviewpager;

/**
 * Created by zhuchenxi on 16/8/4.
 */
public interface OnItemClickListener {
    void onItemClick(int position);
}
