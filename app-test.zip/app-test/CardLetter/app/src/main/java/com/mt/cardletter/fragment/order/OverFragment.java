package com.mt.cardletter.fragment.order;



import com.mt.cardletter.R;
import com.mt.cardletter.fragment.BaseFragment;


/**
 * 已完成
 */
public class OverFragment extends BaseFragment {

    public OverFragment() {
    }
    @Override
    protected int setLayoutResouceId() {
        return R.layout.fragment_apmprepare;
    }

    @Override
    public void initData() {

    }

}
